# Velveteen EchoWhisper
# (see ChatGPT conversation for full script body)
